package org.inceptez.hackk.streaming

import org.apache.spark.{SparkContext,SparkConf}
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming.{Seconds,StreamingContext}
import StreamingContext._
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.streaming.kafka010._
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.elasticsearch.spark.sql._


object rtcustjsonanalysis11 {
  
  val spark = SparkSession.builder().enableHiveSupport().appName("SparkStreamin_eskiabana")
              .master("local[2]")
              .config("spark.history.fs.logDirectory","file:///tmp/spark-events")
              .config("saprk.eventLog.dir","file:///tmp/spark-events")
              .config("spark.evetLog.enabled","true")
              .config("hive.metastore.uris","thrift://localhost:9083")
              .config("spark.sql.warehouse.dir","hdfs://localhost:54310/user/hive/warehouse")
              .config("spark.sql.shuffle.partitions",10)
              .config("spark.es.nodes","localhost")
              .config("spark.es.port","9200")
              .config("es.nodes.wan.only","true")
              .getOrCreate();
  val sc = spark.sparkContext;
  val ssc = new StreamingContext(sc,Seconds(10));
  sc.setLogLevel("error");
  
  val topics = Array("custdatajson");
  val kafkaparams = Map[String,Object] (
      "bootstrap.servers" -> "localhost:9092",
      "key.desrializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "group.id" -> "wd26A",
      "auto.offset.reset" -> "latest",
      "enable.auto.commit" -> (false:java.lang.Boolean) )
      
      val dstream = KafkaUtils.createDirectStream[String,String](ssc,PreferConsistent,Subscribe[String,String](topics,kafkaparams))
      try
  {
        import spark.sqlContext.implicits;
        dstream.foreachRDD{
          rddfromdstream => 
            val offsetranges = rddfromdstream.asInstanceOf[HasOffsetRanges].offsetRanges
            println("Printing Offsets");
            offsetranges.foreach(println);
            
            
            if(!rddfromdstream.isEmpty())
            {
              val jsonrdd = rddfromdstream.map(x=>x.value());
              val jsondf = spark.read.option("multiline","true").option("dropmalformed","true").json(jsonrdd);
              jsondf.printSchema();
              jsondf.show(5,false);
              jsondf.createOrReplaceTempView("jsonapiview");
              spark.sql(""""select 
                explode(results) as res,
info.page as page,res.cell as cell,
res.name.first as first,
res.dob.age as age,
res.dob.date as dobdt,
res.email as email,res.location.city as uscity,res.location.coordinates.latitude as latitude,
res.location.coordinates.longitude as longitude,res.location.country as country,
res.location.state as state,
res.location.timezone as timezone,res.login.username as username,current_date as curdt,current_timestamp as curts
from jsonapiview """").show(5,false)

val esdf = spark.sql(""" 
                    select username as custid, cell,first,age,email, uscity, concat(latitude,’,’,longitude) as coordinates,
                    country, state,dobdt,(case when age = computedAge then 'Valid' else 'Invalid' end) as ageflag ,curdt, curts, page from
                   (select 
                    explode(results) as res,
info.page as page,res.cell as cell,
res.name.first as first,
res.dob.age as age,
res.dob.date as dobdt1,
substr(res.dob.date,1,10) as dobdt,
round(datediff(current_date(),to_date(substr(res.dob.date,1,10)))/365) as computedAge,
res.email as email,res.location.city as uscity,res.location.coordinates.latitude as latitude,
res.location.coordinates.longitude as longitude,res.location.country as country,
res.location.state as state,
res.location.timezone as timezone,res.login.username as username,current_date as curdt,current_timestamp as curts
from jsonapiview) where age>25 """);
              println("Writing to Elastic Search");
              
              esdf.saveToEs("sparkjson/custvist", Map("es.mapping.id"->"custid"));
              dstream.asInstanceOf[CanCommitOffsets].commitAsync(offsetranges)
				println(java.time.LocalTime.now)
				println("commiting offset")
			}
			else
				{println(java.time.LocalTime.now)
				println("No data in the kafka topic for the given iteration")
				}


        
        }
  }
  
  catch {
						case ex1: java.lang.IllegalArgumentException => {
							println("Illegal arg exception")
						}

						case ex2: java.lang.ArrayIndexOutOfBoundsException => {
							println("Array index out of bound")
						}

						case ex3: org.apache.spark.SparkException => {
							println("Spark common exception")}
						
            case ex4: java.lang.NullPointerException => {
							println("Values Ignored")}
						    }
					
		ssc.start()
		ssc.awaitTermination()

  
}