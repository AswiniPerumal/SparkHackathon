package sparkhackathon

import org.apache.spark.{SparkContext,SparkConf}
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel._

object sparkcoresql {
 
 def main(args:Array[String])
 {
 val spark=SparkSession.builder().appName("SparkHackthon_Aswini").master("local[2]").
                        config("spark.eventLog.dir","file:///tmp/spark-events").
                         config("spark.history.fs.logDirectory","file:///tmp/spark-events").
                         config("spark.eventLog.enabled","true").
                         config("hive.metastore.uris","thrift://127.0.0.1:9083").
                         config("spark.sql.warehouse.dir","hdfs://127.0.0.1:54310/user/hive/warehouse").
                         config("spark.sql.shuffle.partitions",10).
                         config("spark.sql.crossJoin.enabled","true").
                         enableHiveSupport().getOrCreate();
 
 spark.sparkContext.setLogLevel("error");
 val sqlc=spark.sqlContext;
 val sc=spark.sparkContext;
 val refmethods = new AllMethods
 //1.Load the file1 (insuranceinfo1.csv) from HDFS using textFile API into an RDD insuredata
 val rdd1=sc.textFile("hdfs://127.0.0.1:54310/user/hduser/sparkhack2/insuranceinfo1.csv");
 //Remove the header line from the RDD contains column names.
 val rmheadrdd=rdd1.first();
 val withoutheaderrdd=rdd1.filter(f=> !f.contains(rmheadrdd));
 //Remove the Footer/trailer also which contains “footer count is 404”
  val totalcount=withoutheaderrdd.count();
 val rddwithIndex= withoutheaderrdd.zipWithIndex();//zipWithIndex return tuples( org.apache.spark.rdd.RDD[(String, Long)]) which in turn returns index starting from 0
 val withoutfooterrdd= rddwithIndex.filter( x=> x._2 < totalcount - 1).map(x=>x._1);
 rdd1.take(3).foreach(println);
 println("count of rdd with header",rdd1.count);
 withoutheaderrdd.take(3).foreach(println);
 println("count of rdd after removing header",totalcount);
 println("count of rdd after removing header",withoutfooterrdd.count);
 //Remove the blank lines in the rdd
 val rdd2 = withoutfooterrdd.map(x => x.trim()).filter(x => x.length() != 0) //val rdd2 = withoutfooterrdd.filter(x => !x.isEmpty);
 //Map and split using ‘,’ delimiter
 val splitrdd = rdd2.map(x=>x.split(",",-1));
 //Filter number of fields are equal to 10 columns only
 val filteredrdd=splitrdd.filter(x=> x.length == 10); // There is a possibility we are getting data from source system where  number of fields in every row is not same, so we are filtering only fixed number of fields rows and we can perform join operations only if we have equal number of column
 /* Add case class namely insureclass with the field names used as per the header record in
the file and apply to the above data to create schemaed RDD */
 println("The Number of rows before cleanup",rdd1.count);
 println("The Number of rows after cleanup",filteredrdd.count);
 //Create another RDD namely rejectdata and store the row that does not equals 10 columns
 val rejectedrdd= splitrdd.filter(x => x.length != 10); 
 /*With a new column added in the first column called numcols contains number
of columns in the given row */
 val deficientrdd=rejectedrdd.map(x=> (x.length,x(0)));
 println("The deficient RDD is " +deficientrdd.first);
 //Load the file2 (insuranceinfo2.csv) from HDFS using textFile API into an RDD insuredata2
 val insureinfordd2= sc.textFile("hdfs://127.0.0.1:54310/user/hduser/sparkhack2/insuranceinfo2.csv");
 /* Repeat from step 2 to 8 for this file also and create the schemaed rdd from the insuranceinfo2.csv and filter the records that contains blank or 
  * null IssuerId,IssuerId2 for eg: remove the records with pattern given below.
           ,,,,,,,13,Individual,Yes */
 
 val rmheadrdd1=insureinfordd2.first();
 val withoutheaderrdd1=insureinfordd2.filter(f=> !f.contains(rmheadrdd1));
 
  val insureinfo2noheadercount = withoutheaderrdd1.count();
  val insureinfo2_nofooter = withoutheaderrdd1.zipWithIndex().filter( x=> x._2 < insureinfo2noheadercount - 1).map(x=>x._1);
 
 println("The count of insureinfo2 rdd including header and footer is :" +insureinfordd2.count);
 println("The count of insureinfo2 rdd without header is :" +insureinfo2noheadercount);
 println("The count of insureinfo2 rdd without header and footer is :" +insureinfo2_nofooter.count);
 
 val withoutblankspacerdd = insureinfo2_nofooter.map(x => x.trim()).filter(x => x.length() != 0) 
 
 val splitrdd1 = withoutblankspacerdd.map(x=>x.split(",",-1));
 val filteredrdd1=splitrdd1.filter(x=> x.length == 10);
 
 val cleansedrdd = filteredrdd1.filter(x => (!(x(0).isEmpty()) || !(x(1).isEmpty())));

 //2. Data merging, Deduplication, Performance Tuning & Persistance
 
 /* Merge the both header and footer removed RDDs derived in steps 8 and 12 into an RDD namely insuredatamerged */
  val insuredatamerged= filteredrdd.union(cleansedrdd).map(x => insureclass(x(0).toInt, x(1).toInt, refmethods.dateformatmet(x(2)), x(3), x(4), x(5), x(6), x(7).toInt,x(8), x(9)));
//val insuredatamerged1 = filteredrdd.union(cleansedrdd).map(x => insureclass(x(0).toInt, x(1).toInt, x(2), x(3), x(4), x(5), x(6), x(7).toInt,x(8), x(9)));
 //Persist the step 13 RDD to memory by serializing.
 insuredatamerged.persist();
 //Calculate the count of rdds created in step 8+12 and rdd in step 13, check whether they are matching
  val mergeddatacount = insuredatamerged.count()
 if( mergeddatacount == (filteredrdd.count() + cleansedrdd.count()))
 {
  println("The count of step8+step12 and merged rdd is matching . .. and the count is " +mergeddatacount);
 }
 //Remove duplicates from this merged RDD created in step 13 and print how many duplicate rows are there
 val deduplicatedrdd = insuredatamerged.distinct();
 val deduplicatedcount = deduplicatedrdd.count();
 val duplicatedrows = mergeddatacount - deduplicatedcount ;
println ("The Count of insuredatamerged is  " +mergeddatacount + " and the deduplicated count is " +deduplicatedcount)
println ("So The Number of Duplicate row is :" +duplicatedrows);
 
//Increase the number of partitions in the above rdd to 8 and name it as insuredatarepart.
val insuredatarepart = deduplicatedrdd.repartition(8);
//Split the above RDD using the businessdate field into rdd_20191001 and rdd_20191002 based on the BusinessDate of 2019-10-01 and 2019-10-02 respectively using Filter function.

//val rdd_20191001 = insuredatarepart.filter
        // val insureDataMergedRDD_Repart_20191001 = insuredatarepart.filter(x => x.BusinessDate == "2019-10-01")
 val insureDataMergedRDD_Repart_20191001 = insuredatarepart.filter(x => x.BusinessDate == "2019-10-01");
 val insureDataMergedRDD_Repart_20191002 = insuredatarepart.filter(x => x.BusinessDate == "2019-10-02");
 //Store the RDDs created in step 10, 13, 18 into HDFS locations.
//deficientrdd.saveAsTextFile("hdfs://localhost:54310/user/hduser/SparkHackathon/rejectdata")
//insuredatamerged.saveAsTextFile("hdfs://localhost:54310/user/hduser/SparkHackathon/Mergeddata");
//insureDataMergedRDD_Repart_20191001.saveAsTextFile("hdfs://localhost:54310//user/hduser/SparkHackathon/rdd_20191001");
//insureDataMergedRDD_Repart_20191002.saveAsTextFile("hdfs://localhost:54310/user/hduser/SparkHackathon/rdd_20191002"); uncomment finally

//Convert the RDD created in step 17 above into Dataframe namely insuredaterepartdf using toDF function
    import sqlc.implicits._
val insuredaterepartdf = insuredatarepart.toDF();

     //Part B - Spark DF & SQL (Step 3, 4 & 5)
     /* Create structuretype for all the columns as per the insuranceinfo1.csv with the columns such as
      * IssuerId,IssuerId2,BusinessDate,StateCode,SourceName,NetworkName,NetworkURL,custnum,MarketCoverage,DentalOnlyPlan*/
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
val insureinfocsv1_Struct = StructType(Array(StructField("IssuerId",IntegerType,false),
          StructField("IssuerId2",IntegerType,false),StructField("BusinessDate",DateType,false),StructField("StateCode",StringType,true),
          StructField("SourceName",StringType,true),StructField("NetworkName",StringType,true),StructField("NetworkURL",StringType,true),
          StructField("custnum",IntegerType,true),StructField("MarketCoverage",StringType,true),StructField("DentalOnlyPlan",StringType,true)))
          
 val insureinfocsv2_Struct = StructType(Array(StructField("IssuerId",IntegerType,false),
          StructField("IssuerId2",IntegerType,false),StructField("BusinessDate",DateType,false),StructField("StateCode",StringType,true),
          StructField("SourceName",StringType,true),StructField("NetworkName",StringType,true),StructField("NetworkURL",StringType,true),
          StructField("custnum",IntegerType,true),StructField("MarketCoverage",StringType,true),StructField("DentalOnlyPlan",StringType,true)))

          /* *Create dataframes using the csv module with option to escape ‘,’ accessing the insuranceinfo1.csv and insuranceinfo2.csv files and remove the footer from both
              dataframes using header true, dropmalformed options and apply the schema of the structure type created in the step 21.*/
 
 val insureinfocsv1df = sqlc.read.option("delimiter",",").option("mode","dropmalformed").option("header","true").schema(insureinfocsv1_Struct).csv("hdfs://127.0.0.1:54310/user/hduser/sparkhack2/insuranceinfo1.csv");
 val insureinfocsv2df = sqlc.read.option("delimiter",",").option("mode","dropmalformed").option("header","true").schema(insureinfocsv2_Struct).csv("hdfs://127.0.0.1:54310/user/hduser/sparkhack2/insuranceinfo2.csv");
 // or
 val insureinfocsv1_2 = sqlc.read.option("delimiter",",").option("mode","dropmalformed").option("header","true").schema(insureinfocsv1_Struct).csv("hdfs://127.0.0.1:54310/user/hduser/sparkhack2/insuranceinfo1.csv","hdfs://127.0.0.1:54310/user/hduser/sparkhack2/insuranceinfo2.csv");
 val insureinfocsv_NoDup = insureinfocsv1_2.dropDuplicates(); 
 println("The Count Before droping Duplicates is " +insureinfocsv1_2.count+"\n"+"The count after droping duplicates is "+insureinfocsv_NoDup.count);
/* 23. Apply the below DSL functions in the DFs created in step 22.
a. Rename the fields StateCode and SourceName as stcd and srcnm respectively.
b. Concat IssuerId,IssuerId2 as issueridcomposite and make it as a new field
Hint : Cast to string and concat.
c. Remove DentalOnlyPlan column
d. Add columns that should show the current system date and timestamp with the
fields name of sysdt and systs respectively. */
 
//val renamedf = insureinfocsv1df.withColumn()
// val renamedinsuredf = insureinfocsv_NoDup.select(concat(col("IssuerId".toString),col("IssuerId2".toString).as("issueridcomposite"),col("IssuerId"),col("IssuerId2"),col("BusinessDate"),col("StateCode").as("stcd"),col("SourceName").as("srcnm"),col("NetworkName"), col("NetworkURL"), col("custnum"), col("MarketCoverage"),current_date().as("sysdt"),current_timestamp().as("systs")));
 val renamedinsuredf = insureinfocsv_NoDup.
          select(concat(col("IssuerId".toString()),col("IssuerId2".toString())).as("issuerIdComposite"),
          col("IssuerId").as("IssuerId"),col("IssuerId2").as("IssuerId2"),col("BusinessDate"),
          col("StateCode").as("stcd"),col("SourceName").as("srcnm"),col("NetworkName"),col("NetworkURL"),col("custnum").as("custnum"),
          col("MarketCoverage"), current_date().as("sysdt"), current_timestamp().as("systs"))
 
 //Identify all the column names and store in an array variable – use columns function.
 val columnnames = renamedinsuredf.columns;
 println("Printng the column names:")
 println(columnnames.mkString(","));
 // Identify all columns with datatype and store in an array variable – use dtypes function         
 val columnnamewithtype = renamedinsuredf.dtypes;
 println("Printing Column name along with datatype : ");
 println(columnnamewithtype.mkString(","));
 //Identify all integer columns alone and store in an array variable.
 val Integercolumndf = renamedinsuredf.dtypes.filter(x => (x._2.toUpperCase() == "INTEGERTYPE"));
 println("Printing the Integer Type Columns");
 println(Integercolumndf.mkString(","));
 //Select only the integer columns identified in the above statement and show 10 records in the screen.
 val intcol = Integercolumndf.map(x=> col(x._1));
 val tenintcoldf = renamedinsuredf.select(intcol.map(x=>x):_*);
 tenintcoldf.show(10,false);
 //Take the DF created in step 23.d and Remove the rows contains null in any one of the field and count the number of rows which contains all columns with some value.
  val removenulldf = renamedinsuredf.na.drop("any");
  println("the number of rows which contains all columns with some value is : " +removenulldf.count);
 import org.inceptez.hackk._
 //Call the above udf in the DSL by passing NetworkName column as an argument to get the special characters removed DF
 val allmethodsobj = new alllmethods();
 val remspecialcharobj = udf(allmethodsobj.remspecialchar _);
 val NetworkNamedf = removenulldf.
  select(col("issuerIdComposite"),
          col("IssuerId").as("IssuerId"),col("IssuerId2").as("IssuerId2"),col("BusinessDate"),
          col("stcd"),col("srcnm"),col("NetworkName"),remspecialcharobj(col("NetworkName")).as("NetworkNameEdited"),col("NetworkURL"),col("custnum").as("custnum"),
          col("MarketCoverage"), col("sysdt"), col("systs"));           
 //Save the DF generated in step 27 in JSON into HDFS with overwrite option.
 println("Writing in JSON format..");
 //NetworkNamedf.coalesce(1).write.mode("overwrite").json("hdfs://localhost:54310/user/hduser/SparkHackathon/insuredatadf_json"); // uncooment later
 //Save the DF generated in step 27 into CSV format with header name as per the DF and delimited by ~ into HDFS with overwrite option
 println("Writing in csv format..")
 //NetworkNamedf.coalesce(1).write.mode("overwrite").option("header",true).option("delimiter","~").csv("hdfs://localhost:54310/user/hduser/SparkHackathon/insuredatadf_csv"); // uncomment later
 //Save the DF generated in step 27 into hive external table and append the data without overwriting it.
 println("Savin the data to hive External table");
 //spark.sql("drop table if exists default.tblinsureinfo")
 //NetworkNamedf.coalesce(1).write.option("mode","append").saveAsTable("default.tblinsureinfo"); //uncomment
 // 4. Tale of handling RDDs, DFs and TempViews
 
 /* Load the file3 (custs_states.csv) from the HDFS location, using textfile API in an RDD custstates, this file contains 2 type of data one with 5 columns contains 
  * customer master info and other data with statecode and description of 2 columns*/
 val custstatesrdd = sc.textFile("hdfs://127.0.0.1:54310/user/hduser/sparkhack2/custs_states.csv");
 /* Split the above data into 2 RDDs, first RDD namely custfilter should be loaded only with
5 columns data and second RDD namely statesfilter should be only loaded with 2 columns data */
 val custfilterrdd = custstatesrdd.map(x=>x.split(",")).filter(x => x.length == 5);
 val statesfilterrdd = custstatesrdd.map(x=>x.split(",")).filter(x=>x.length == 2);
 /* Load the file3 (custs_states.csv) from the HDFS location, using CSV Module in a DF custstatesdf, this file contains 2 type of data one with 5 columns contains 
  * customer master info and other data with statecode and description of 2 columns*/
 val custstatesdf = spark.read.option("delimiter",",").option("mode","permissive").option("header","false").csv("hdfs://127.0.0.1:54310/user/hduser/sparkhack2/custs_states.csv");
 /* Split the above data into 2 DFs, first DF namely custfilterdf should be loaded only with 5
columns data and second DF namely statesfilterdf should be only loaded with 2 columns data*/
 val custfilterdf= custstatesdf.where("_c2 is not null").select(col("_c0").as ("custid"),col("_c1").as ("custfirstname"),col("_c2").as ("custlastname"),col("_c3").as ("age"),col("_c4").as ("profession"));
 val statesfilterdf = custstatesdf.where("_c2 is null").select(col("_c0").as ("statecode"),col("_c1").as ("statename"));
 
 //Register the above step 34 DFs as temporary views as custview and statesview
 custfilterdf.createOrReplaceTempView("custview");
 statesfilterdf.createOrReplaceTempView("statesview");
 //Register the DF generated in step 23.d as a tempview namely insureview
 renamedinsuredf.createOrReplaceTempView("insureview");
 //Import the package, instantiate the class and Register the method created in step 25 in the name of remspecialcharudf using spark udf registration.
 spark.udf.register("remspecialcharudf",remspecialcharobj);
 // 38. Write an SQL query with the below processing – set the spark.sql.shuffle.partitions to 4
 
 /*a. Pass NetworkName to remspecialcharudf and get the new column called cleannetworkname
   b. Add current date, current timestamp fields as curdt and curts.
   c. Extract the year and month from the businessdate field and get it as 2 new fields called yr,mth respectively.
   d. Extract from the protocol either http/https from the NetworkURL column, if http then print http non secured if https then secured else no protocol found then
      display noprotocol. For Eg: if http://www2.dentemax.com/ then show http non secured else if https://www2.dentemax.com/ then http secured else if
      www.brcustnumidgespanhealth.com then show as no protocol store in a column called protocol.
   e. Display all the columns from insureview including the columns derived from above a, b, c, d steps with statedesc column from statesview with age,profession
      column from custview . Do an Inner Join of insureview with statesview using
      stcd=stated and join insureview with custview using =custid */
 spark.conf.set("spark.sql.shuffle.partitions",4);
 val insurecutstatesjoneddf = spark.sql(""" 
   select  iv.issuerIdComposite, iv.IssuerId , iv.IssuerId2, iv.custnum , iv.BusinessDate,
           remspecialcharudf(iv.NetworkName) cleannetworkname , iv.MarketCoverage, iv.NetworkURL ,
           iv.stcd , iv.srcnm , iv.sysdt curdt , iv.systs curts , extract(year from iv.BusinessDate) yr , extract(month from iv.BusinessDate) mth ,
          (case when upper(substr(iv.NetworkURL,1,instr(iv.NetworkURL,":") - 1)) == 'HTTPS' then 'https'
           when upper(substr(iv.NetworkURL,1,instr(iv.NetworkURL,":") - 1)) == 'HTTP' then 'http'
           else 'no protocol' end) as prtype,
            (case when upper(substr(iv.NetworkURL,1,instr(iv.NetworkURL,":") - 1)) == 'HTTPS' then 'secured'
           when upper(substr(iv.NetworkURL,1,instr(iv.NetworkURL,":") - 1)) == 'HTTP' then 'Not secured'
           else 'no protocol' end) as protocol,
           sv.statecode,sv.statename,
           cv.custid,cv.custfirstname,cv.custlastname,cv.age,cv.profession
           from insureview iv , statesview sv , custview cv
           where iv.custnum = cv.custid
           and iv.stcd = sv.statecode """).coalesce(1);
 //Store the above selected Dataframe in Parquet formats in a HDFS location as a single file
 println("Writing in parquet format ...");
 //insurecutstatesjoneddf.coalesce(1).write.mode("overwrite").parquet("hdfs://localhost:54310/user/hduser/SparkHackathon/insuredatadf_parquet");
 /* 40. Write an SQL query to identify average age, count group by statedesc, protocol,
profession including a seqno column added which should have running sequence
number partitioned based on protocol and ordered based on count descending and
display the profession whose second highest average age of a given state and protocol.*/
 
 insurecutstatesjoneddf.createOrReplaceTempView("insurecutstatesview");
 val aggdf=spark.sql("""select seqno,v1.avg_Age, v1.count_s, v1.statename, v1.protocol, v1.profession from (
  	    select row_number() over(partition by temp_view.protocol order by temp_view.count_s desc) as seqno,
  	    temp_view.avg_Age as avg_Age, temp_view.count_s as count_s, temp_view.statename as statename, 
  	    temp_view.protocol as protocol, temp_view.profession as profession
  	    from
  	    (select avg(a.age) as avg_Age, count(1) as count_s, a.statename as statename, a.protocol as protocol, 
  	    a.profession as profession
  	    from insurecutstatesview a
  	    group by a.stateName, a.protocol, a.profession) temp_view) v1
  	    where seqno = 2""").show();
 
 //Store the DF generated in step 39 into MYSQL table insureaggregated
 println("Writing to MYSQL table ..");
 val prop= new java.util.Properties();
 prop.put("user", "root");
 prop.put("password", "Root123$");
 //insurecutstatesjoneddf.write.option("driver","com.mysql.cj.jdbc.Driver").mode("overwrite").jdbc("jdbc:mysql://127.0.0.1:3306/custdb","insureaggregated",prop );
 
 }
 
 }
