package sparkhackathon

import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD

case class insureclass(IssuerId:Long,IssuerId2:Long,BusinessDate:String,StateCode:String,SourceName:String,NetworkName:String,NetworkURL:String,custnum:Int,MarketCoverage:String,DentalOnlyPlan:String); // move case class to separate class later

class AllMethods extends java.io.Serializable {

  def dateformatmet(inputdate:String):String = 
  {
    var formateddate = ""
    if (inputdate.substring(0,4).contains("-"))
    {
      if (inputdate.count(_ == '-') == 2) // checking if it contains 2 "-"
      {
        //01-10-2019
        formateddate = inputdate.substring(6,10)+"-"+inputdate.substring(3,5)+"-"+inputdate.substring(0,2)
      }
    }
    else
      formateddate = inputdate
    return formateddate
  }  

}