package org.inceptez.hackk

import org.apache.hadoop.hive.ql.exec.Description
import org.apache.hadoop.hive.ql.exec.UDF

class alllmethods extends UDF with java.io.Serializable {
  def remspecialchar(inputstr:String):String =
  {
   var outputstr:String="";
   outputstr = inputstr.replaceAll("[0-9-?,/()\\[\\]]", "");
   return outputstr;
  }
  
  
}